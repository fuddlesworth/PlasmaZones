// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details

#include "Luau/Generalization.h"

#include "Luau/Common.h"
#include "Luau/DenseHash.h"
#include "Luau/InsertionOrderedMap.h"
#include "Luau/IterativeTypeVisitor.h"
#include "Luau/OrderedSet.h"
#include "Luau/Polarity.h"
#include "Luau/Scope.h"
#include "Luau/ToString.h"
#include "Luau/Type.h"
#include "Luau/TypeArena.h"
#include "Luau/TypeIds.h"
#include "Luau/TypePack.h"
#include "Luau/TypeUtils.h"
#include "Luau/VisitType.h"

LUAU_FASTINTVARIABLE(LuauGenericCounterMaxDepth, 15)
LUAU_FASTINTVARIABLE(LuauGenericCounterMaxSteps, 1500)
LUAU_FASTFLAGVARIABLE(LuauIterativeTypeSearcher)

namespace Luau
{

struct FreeTypeSearcher_DEPRECATED : TypeVisitor
{
    NotNull<Scope> scope;
    NotNull<DenseHashSet<TypeId>> cachedTypes;

    explicit FreeTypeSearcher_DEPRECATED(NotNull<Scope> scope, NotNull<DenseHashSet<TypeId>> cachedTypes)
        : TypeVisitor("FreeTypeSearcher", /* skipBoundTypes */ true)
        , scope(scope)
        , cachedTypes(cachedTypes)
    {
    }

    bool isWithinFunction = false;
    Polarity polarity = Polarity::Positive;

    void flip()
    {
        polarity = invert(polarity);
    }

    DenseHashSet<const void*> seenPositive;
    DenseHashSet<const void*> seenNegative;

    bool seenWithCurrentPolarity(const void* ty)
    {
        switch (polarity)
        {
        case Polarity::Positive:
        {
            if (seenPositive.contains(ty))
                return true;

            seenPositive.insert(ty);
            return false;
        }
        case Polarity::Negative:
        {
            if (seenNegative.contains(ty))
                return true;

            seenNegative.insert(ty);
            return false;
        }
        case Polarity::Mixed:
        {
            if (seenPositive.contains(ty) && seenNegative.contains(ty))
                return true;

            seenPositive.insert(ty);
            seenNegative.insert(ty);
            return false;
        }
        default:
            LUAU_ASSERT(!"Unreachable");
        }

        return false;
    }

    DenseHashMap<const void*, size_t> negativeTypes;
    DenseHashMap<const void*, size_t> positiveTypes;

    InsertionOrderedMap<TypeId, GeneralizationParams<TypeId>> types;
    InsertionOrderedMap<TypePackId, GeneralizationParams<TypePackId>> typePacks;

    OrderedSet<TypeId> unsealedTables;

    bool visit(TypeId ty) override
    {
        if (cachedTypes->contains(ty) || seenWithCurrentPolarity(ty))
            return false;

        LUAU_ASSERT(ty);
        return true;
    }

    bool visit(TypeId ty, const FreeType& ft) override
    {
        if (!subsumes(scope, ft.scope))
            return true;

        GeneralizationParams<TypeId>& params = types[ty];
        ++params.useCount;

        if (cachedTypes->contains(ty) || seenWithCurrentPolarity(ty))
            return false;

        if (!isWithinFunction)
            params.foundOutsideFunctions = true;

        params.polarity |= polarity;

        return true;
    }

    bool visit(TypeId ty, const TableType& tt) override
    {
        if (cachedTypes->contains(ty) || seenWithCurrentPolarity(ty))
            return false;

        if ((tt.state == TableState::Free || tt.state == TableState::Unsealed) && subsumes(scope, tt.scope))
            unsealedTables.insert(ty);

        for (const auto& [_name, prop] : tt.props)
        {
            if (prop.isReadOnly())
            {
                traverse(*prop.readTy);
            }
            else if (prop.isWriteOnly())
            {
                Polarity p = polarity;
                polarity = Polarity::Negative;
                traverse(*prop.writeTy);
                polarity = p;
            }
            else if (prop.isShared())
            {
                Polarity p = polarity;
                polarity = Polarity::Mixed;
                traverse(*prop.readTy);
                polarity = p;
            }
            else
            {
                LUAU_ASSERT(prop.isReadWrite() && !prop.isShared());

                traverse(*prop.readTy);
                Polarity p = polarity;
                polarity = Polarity::Negative;
                traverse(*prop.writeTy);
                polarity = p;
            }
        }

        if (tt.indexer)
        {
            // {[K]: V} is equivalent to three functions: get, set, and iterate
            //
            // (K) -> V
            // (K, V) -> ()
            // () -> {K}
            //
            // K and V therefore both have mixed polarity.

            const Polarity p = polarity;
            polarity = Polarity::Mixed;
            traverse(tt.indexer->indexType);
            traverse(tt.indexer->indexResultType);
            polarity = p;
        }

        return false;
    }

    bool visit(TypeId ty, const FunctionType& ft) override
    {
        if (cachedTypes->contains(ty) || seenWithCurrentPolarity(ty))
            return false;

        const bool oldValue = isWithinFunction;
        isWithinFunction = true;

        flip();
        traverse(ft.argTypes);
        flip();

        traverse(ft.retTypes);

        isWithinFunction = oldValue;

        return false;
    }

    bool visit(TypeId, const ExternType&) override
    {
        return false;
    }

    bool visit(TypePackId tp, const FreeTypePack& ftp) override
    {
        if (seenWithCurrentPolarity(tp))
            return false;

        if (!subsumes(scope, ftp.scope))
            return true;

        GeneralizationParams<TypePackId>& params = typePacks[tp];
        ++params.useCount;

        if (!isWithinFunction)
            params.foundOutsideFunctions = true;

        params.polarity |= polarity;

        return true;
    }
};

// We keep a running set of types that will not change under generalization and
// only have outgoing references to types that are the same.  We use this to
// short circuit generalization.  It improves performance quite a lot.
//
// We do this by tracing through the type and searching for types that are
// uncacheable. If a type has a reference to an uncacheable type, it is itself
// uncacheable.
//
// If a type has no outbound references to uncacheable types, we add it to the
// cache.
struct TypeCacher : TypeOnceVisitor
{
    NotNull<DenseHashSet<TypeId>> cachedTypes;

    DenseHashSet<TypeId> uncacheable;
    DenseHashSet<TypePackId> uncacheablePacks;

    explicit TypeCacher(NotNull<DenseHashSet<TypeId>> cachedTypes)
        : TypeOnceVisitor("TypeCacher", /* skipBoundTypes */ true)
        , cachedTypes(cachedTypes)
    {
    }

    void cache(TypeId ty) const
    {
        cachedTypes->insert(follow(ty));
    }

    bool isCached(TypeId ty) const
    {
        return cachedTypes->contains(follow(ty));
    }

    void markUncacheable(TypeId ty)
    {
        uncacheable.insert(follow(ty));
    }

    void markUncacheable(TypePackId tp)
    {
        uncacheablePacks.insert(follow(tp));
    }

    bool isUncacheable(TypeId ty) const
    {
        return uncacheable.contains(follow(ty));
    }

    bool isUncacheable(TypePackId tp) const
    {
        return uncacheablePacks.contains(follow(tp));
    }

    bool visit(TypeId ty) override
    {
        // NOTE: `TypeCacher` should explicitly visit _all_ types and type packs,
        // otherwise it's prone to marking types that cannot be cached as
        // cacheable.
        LUAU_ASSERT(false);
        LUAU_UNREACHABLE();
    }

    bool visit(TypeId ty, const FreeType& ft) override
    {
        // Free types are never cacheable.
        LUAU_ASSERT(!isCached(ty));

        if (!isUncacheable(ty))
        {
            traverse(ft.lowerBound);
            traverse(ft.upperBound);

            markUncacheable(ty);
        }

        return false;
    }

    bool visit(TypeId ty, const GenericType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const ErrorType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const PrimitiveType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const SingletonType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const BlockedType&) override
    {
        markUncacheable(ty);
        return false;
    }

    bool visit(TypeId ty, const PendingExpansionType&) override
    {
        markUncacheable(ty);
        return false;
    }

    bool visit(TypeId ty, const FunctionType& ft) override
    {
        if (isCached(ty) || isUncacheable(ty))
            return false;

        traverse(ft.argTypes);
        traverse(ft.retTypes);
        for (TypeId gen : ft.generics)
            traverse(gen);

        bool uncacheable = false;

        if (isUncacheable(ft.argTypes))
            uncacheable = true;

        else if (isUncacheable(ft.retTypes))
            uncacheable = true;

        for (TypeId argTy : ft.argTypes)
        {
            if (isUncacheable(argTy))
            {
                uncacheable = true;
                break;
            }
        }

        for (TypeId retTy : ft.retTypes)
        {
            if (isUncacheable(retTy))
            {
                uncacheable = true;
                break;
            }
        }

        for (TypeId g : ft.generics)
        {
            if (isUncacheable(g))
            {
                uncacheable = true;
                break;
            }
        }

        if (uncacheable)
            markUncacheable(ty);
        else
            cache(ty);

        return false;
    }

    bool visit(TypeId ty, const TableType& tt) override
    {
        if (isCached(ty) || isUncacheable(ty))
            return false;

        if (tt.boundTo)
        {
            traverse(*tt.boundTo);
            if (isUncacheable(*tt.boundTo))
            {
                markUncacheable(ty);
                return false;
            }
        }

        bool uncacheable = false;

        // This logic runs immediately after generalization, so any remaining
        // unsealed tables are assuredly not cacheable.  They may yet have
        // properties added to them.
        if (tt.state == TableState::Free || tt.state == TableState::Unsealed)
            uncacheable = true;

        for (const auto& [_name, prop] : tt.props)
        {
            if (prop.readTy)
            {
                traverse(*prop.readTy);

                if (isUncacheable(*prop.readTy))
                    uncacheable = true;
            }
            if (prop.writeTy && prop.writeTy != prop.readTy)
            {
                traverse(*prop.writeTy);

                if (isUncacheable(*prop.writeTy))
                    uncacheable = true;
            }
        }

        if (tt.indexer)
        {
            traverse(tt.indexer->indexType);
            if (isUncacheable(tt.indexer->indexType))
                uncacheable = true;

            traverse(tt.indexer->indexResultType);
            if (isUncacheable(tt.indexer->indexResultType))
                uncacheable = true;
        }

        if (uncacheable)
            markUncacheable(ty);
        else
            cache(ty);

        return false;
    }

    bool visit(TypeId ty, const MetatableType& mtv) override
    {
        traverse(mtv.table);
        traverse(mtv.metatable);
        if (isUncacheable(mtv.table) || isUncacheable(mtv.metatable))
            markUncacheable(ty);
        else
            cache(ty);
        return false;
    }

    bool visit(TypeId ty, const ExternType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const AnyType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const NoRefineType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const UnionType& ut) override
    {
        if (isUncacheable(ty) || isCached(ty))
            return false;

        bool uncacheable = false;

        for (TypeId partTy : ut.options)
        {
            traverse(partTy);

            uncacheable |= isUncacheable(partTy);
        }

        if (uncacheable)
            markUncacheable(ty);
        else
            cache(ty);

        return false;
    }

    bool visit(TypeId ty, const IntersectionType& it) override
    {
        if (isUncacheable(ty) || isCached(ty))
            return false;

        bool uncacheable = false;

        for (TypeId partTy : it.parts)
        {
            traverse(partTy);

            uncacheable |= isUncacheable(partTy);
        }

        if (uncacheable)
            markUncacheable(ty);
        else
            cache(ty);

        return false;
    }

    bool visit(TypeId ty, const UnknownType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const NeverType&) override
    {
        cache(ty);
        return false;
    }

    bool visit(TypeId ty, const NegationType& nt) override
    {
        if (!isCached(ty) && !isUncacheable(ty))
        {
            traverse(nt.ty);

            if (isUncacheable(nt.ty))
                markUncacheable(ty);
            else
                cache(ty);
        }

        return false;
    }

    bool visit(TypeId ty, const TypeFunctionInstanceType& tfit) override
    {
        if (isCached(ty) || isUncacheable(ty))
            return false;

        bool uncacheable = false;

        for (TypeId argTy : tfit.typeArguments)
        {
            traverse(argTy);

            if (isUncacheable(argTy))
                uncacheable = true;
        }

        for (TypePackId argPack : tfit.packArguments)
        {
            traverse(argPack);

            if (isUncacheable(argPack))
                uncacheable = true;
        }

        if (uncacheable)
            markUncacheable(ty);
        else
            cache(ty);

        return false;
    }

    bool visit(TypePackId tp) override
    {
        // NOTE: `TypeCacher` should explicitly visit _all_ types and type packs,
        // otherwise it's prone to marking types that cannot be cached as
        // cacheable, which will segfault down the line.
        LUAU_ASSERT(false);
        LUAU_UNREACHABLE();
    }

    bool visit(TypePackId tp, const FreeTypePack&) override
    {
        markUncacheable(tp);
        return false;
    }

    bool visit(TypePackId tp, const GenericTypePack& gtp) override
    {
        return true;
    }

    bool visit(TypePackId tp, const ErrorTypePack& etp) override
    {
        return true;
    }

    bool visit(TypePackId tp, const VariadicTypePack& vtp) override
    {
        if (isUncacheable(tp))
            return false;

        traverse(vtp.ty);

        if (isUncacheable(vtp.ty))
            markUncacheable(tp);

        return false;
    }

    bool visit(TypePackId tp, const BlockedTypePack&) override
    {
        markUncacheable(tp);
        return false;
    }

    bool visit(TypePackId tp, const TypeFunctionInstanceTypePack&) override
    {
        markUncacheable(tp);
        return false;
    }

    bool visit(TypePackId tp, const BoundTypePack& btp) override
    {
        traverse(btp.boundTo);
        if (isUncacheable(btp.boundTo))
            markUncacheable(tp);
        return false;
    }

    bool visit(TypePackId tp, const TypePack& typ) override
    {
        bool uncacheable = false;
        for (TypeId ty : typ.head)
        {
            traverse(ty);
            uncacheable |= isUncacheable(ty);
        }
        if (typ.tail)
        {
            traverse(*typ.tail);
            uncacheable |= isUncacheable(*typ.tail);
        }
        if (uncacheable)
            markUncacheable(tp);
        return false;
    }
};

namespace
{

struct TypeRemover
{
    NotNull<BuiltinTypes> builtinTypes;
    NotNull<TypeArena> arena;

    TypeId needle;
    DenseHashSet<TypeId> seen;

    void process(TypeId item)
    {
        item = follow(item);

        // If we've already visited this item, or it's outside our arena, then
        // do not try to mutate it.
        if (seen.contains(item) || item->owningArena != arena || item->persistent)
            return;
        seen.insert(item);

        if (auto ut = getMutable<UnionType>(item))
        {
            TypeIds newOptions;
            for (TypeId option : ut->options)
            {
                process(option);
                option = follow(option);
                if (option != needle && !is<NeverType>(option) && option != item)
                    newOptions.insert(option);
            }
            if (ut->options.size() != newOptions.size())
            {
                if (newOptions.empty())
                    emplaceType<BoundType>(asMutable(item), builtinTypes->neverType);
                else if (newOptions.size() == 1)
                    emplaceType<BoundType>(asMutable(item), *newOptions.begin());
                else
                    emplaceType<BoundType>(asMutable(item), arena->addType(UnionType{newOptions.take()}));
            }
        }
        else if (auto it = getMutable<IntersectionType>(item))
        {
            TypeIds newParts;
            for (TypeId part : it->parts)
            {
                process(part);
                part = follow(part);
                if (part != needle && !is<UnknownType>(part) && part != item)
                    newParts.insert(part);
            }
            if (it->parts.size() != newParts.size())
            {
                if (newParts.empty())
                    emplaceType<BoundType>(asMutable(item), builtinTypes->unknownType);
                else if (newParts.size() == 1)
                    emplaceType<BoundType>(asMutable(item), *newParts.begin());
                else
                    emplaceType<BoundType>(asMutable(item), arena->addType(IntersectionType{newParts.take()}));
            }
        }
    }
};

void removeType(NotNull<TypeArena> arena, NotNull<BuiltinTypes> builtinTypes, TypeId haystack, TypeId needle)
{
    TypeRemover tr{builtinTypes, arena, needle};
    tr.process(haystack);
}

struct FreeTypeFinder_DEPRECATED : TypeOnceVisitor
{
    NotNull<TypeArena> arena;
    TypeIds freeTys;

    explicit FreeTypeFinder_DEPRECATED(NotNull<TypeArena> arena)
        : TypeOnceVisitor("FreeTypeFinder", /*skipBoundTypes*/ true)
        , arena(arena)
    {
    }

    bool visit(TypeId ty, const FreeType&) override
    {
        if (ty->owningArena != arena)
            return false;

        freeTys.insert(ty);
        return true;
    }

    bool visit(TypeId ty, const TableType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const MetatableType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const FunctionType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const ExternType&) override
    {
        return false;
    }
};

struct FreeTypeFinder : IterativeTypeVisitor
{
    NotNull<TypeArena> arena;
    TypeIds freeTys;

    explicit FreeTypeFinder(NotNull<TypeArena> arena)
        : IterativeTypeVisitor("FreeTypeFinder", /* visitOnce */ true, /*skipBoundTypes*/ true)
        , arena(arena)
    {
    }

    bool visit(TypeId ty, const FreeType&) override
    {
        if (ty->owningArena != arena)
            return false;

        freeTys.insert(ty);
        return true;
    }

    bool visit(TypeId ty, const TableType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const MetatableType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const FunctionType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const ExternType&) override
    {
        return false;
    }
};

TypeId getDirectFreeNeighbor(TypeId ty)
{
    ty = follow(ty);
    if (get<FreeType>(ty))
        return ty;
    return nullptr;
}

void collapseInvariantFreeType(NotNull<TypeArena> arena, TypeId ty)
{
    if (FFlag::LuauIterativeTypeSearcher)
    {
        FreeTypeFinder ftf{arena};
        ftf.run(ty);

        for (TypeId t : ftf.freeTys)
        {
            const FreeType* ft = get<FreeType>(t);
            LUAU_ASSERT(ft);

            auto ub = follow(ft->upperBound);
            auto lb = follow(ft->lowerBound);
            if (ub == lb && ub != t)
                emplaceType<BoundType>(asMutable(t), ub);
        }
    }
    else
    {
        FreeTypeFinder_DEPRECATED ftf{arena};
        ftf.traverse(ty);

        for (TypeId t : ftf.freeTys)
        {
            const FreeType* ft = get<FreeType>(t);
            LUAU_ASSERT(ft);

            auto ub = follow(ft->upperBound);
            auto lb = follow(ft->lowerBound);
            if (ub == lb && ub != t)
                emplaceType<BoundType>(asMutable(t), ub);
        }
    }
}


// Walk direct free-type bounds starting from `startTy`.  If a cycle is
// reachable, collapse every member into one representative free type whose
// bounds are the union of every member's external lower bound and the
// intersection of every member's external upper bound.  Cycle self-references
// (whether direct or nested in unions/intersections) are stripped from those
// bounds.
//
// A "direct bound" means A.lowerBound or A.upperBound IS another free type
// (not nested inside a union/intersection/table/function).  Cycles formed by
// direct bounds (A->B->...->A) are the only cycles this helper detects;
// non-cycling chains are left alone.
//
// Returns true if any types were collapsed.
bool collapseDirectBoundCycleAt(NotNull<TypeArena> arena, NotNull<BuiltinTypes> builtinTypes, TypeId startTy)
{
    if (FFlag::LuauRemovePrimitiveTypeConstraintAndSubtypingUnifier)
        collapseInvariantFreeType(arena, startTy);

    startTy = follow(startTy);

    if (!get<FreeType>(startTy))
        return false;

    TypeIds path;
    TypeId cur = startTy;

    while (cur)
    {
        if (path.contains(cur))
        {
            // Collect cycle members: everything on the path from `cur` onward.
            TypeIds cycleMembers;
            bool inCycle = false;
            for (TypeId member : path)
            {
                if (member == cur)
                    inCycle = true;
                if (inCycle)
                    cycleMembers.insert(member);
            }
            LUAU_ASSERT(!cycleMembers.empty());

            // Merge external bounds from every cycle member into the
            // representative.  Lower bounds union; upper bounds intersect.
            // Skip bounds that are entirely cycle self-refs.
            UnionBuilder mergedLowers{arena, builtinTypes};
            IntersectionBuilder mergedUppers{arena, builtinTypes};

            for (TypeId m : cycleMembers)
            {
                FreeType* ft = getMutable<FreeType>(m);
                if (!ft)
                    continue;

                TypeId lb = follow(ft->lowerBound);
                if (!cycleMembers.contains(lb))
                {
                    for (TypeId other : cycleMembers)
                        removeType(arena, builtinTypes, lb, other);
                    lb = follow(lb);
                    if (!get<NeverType>(lb) && !cycleMembers.contains(lb))
                        mergedLowers.add(lb);
                }

                TypeId ub = follow(ft->upperBound);
                if (!cycleMembers.contains(ub))
                {
                    for (TypeId other : cycleMembers)
                        removeType(arena, builtinTypes, ub, other);
                    ub = follow(ub);
                    if (!get<UnknownType>(ub) && !cycleMembers.contains(ub))
                        mergedUppers.add(ub);
                }
            }

            // Pick the back-edge target (cycleMembers[0] = `cur`) as the
            // representative, give it the merged bounds, and bind the rest.
            TypeId rep = cycleMembers.front();
            FreeType* repFree = getMutable<FreeType>(rep);
            LUAU_ASSERT(repFree);

            repFree->lowerBound = mergedLowers.build();
            repFree->upperBound = mergedUppers.build();

            auto it = cycleMembers.begin() + 1;
            while (it != cycleMembers.end())
            {
                emplaceType<BoundType>(asMutable(*it), rep);
                ++it;
            }

            return true;
        }

        path.insert(cur);

        FreeType* ft = getMutable<FreeType>(cur);
        if (!ft)
            break;

        // Try to follow a direct free-type bound (prefer upper, then lower).
        TypeId next = getDirectFreeNeighbor(ft->upperBound);
        if (!next || next == cur)
            next = getDirectFreeNeighbor(ft->lowerBound);
        if (next == cur)
            next = nullptr;

        cur = next;
    }

    return false;
}

// Batch pre-pass: collapse direct-bound cycles among the free types in the
// generalization frontier.  Iteration order does not matter -- once a cycle
// has been collapsed, subsequent walks from any member terminate immediately
// because the type is no longer free (it has been bound to the rep) or
// because the rep's bounds no longer reference cycle members.
void collapseFreeTypeCycles(
    NotNull<TypeArena> arena,
    NotNull<BuiltinTypes> builtinTypes,
    const InsertionOrderedMap<TypeId, GeneralizationParams<TypeId>>& freeTypes
)
{
    for (const auto& [startTy, _] : freeTypes)
        collapseDirectBoundCycleAt(arena, builtinTypes, startTy);
}

struct CollectFreeTypePolarities
{
    NotNull<Scope> scope;
    NotNull<DenseHashSet<TypeId>> cachedTypes;

    explicit CollectFreeTypePolarities(NotNull<Scope> scope, NotNull<DenseHashSet<TypeId>> cachedTypes)
        : scope(scope)
        , cachedTypes(cachedTypes)
    {
    }

    DenseHashSet<const void*> seenPositive;
    DenseHashSet<const void*> seenNegative;

    InsertionOrderedMap<TypeId, GeneralizationParams<TypeId>> types;
    InsertionOrderedMap<TypePackId, GeneralizationParams<TypePackId>> typePacks;

    OrderedSet<TypeId> unsealedTables;

    struct WorkItem
    {
        Luau::Variant<TypeId, TypePackId> value;
        Polarity polarity;
        bool isWithinFunction;
    };

    std::vector<WorkItem> work;

    bool seenWithPolarity(const void* ty, Polarity polarity) const
    {
        switch (polarity)
        {
        case Polarity::Positive:
            return seenPositive.contains(ty);
        case Polarity::Negative:
            return seenNegative.contains(ty);
        case Polarity::Mixed:
            return seenPositive.contains(ty) && seenNegative.contains(ty);
        case Polarity::None:
        case Polarity::Unknown:
        default:
            LUAU_ASSERT(!"Unreachable");
        }
        // This should only occur if we hit the "unreachable" branch above.
        return true;
    }

    void observe(const void* ty, Polarity polarity)
    {
        if (isPositive(polarity))
            seenPositive.insert(ty);

        if (isNegative(polarity))
            seenNegative.insert(ty);
    }

    void push(TypePackId tp, Polarity polarity, bool isWithinFunction)
    {
        tp = follow(tp);
        if (!seenWithPolarity(tp, polarity))
        {
            observe(tp, polarity);
            work.push_back({tp, polarity, isWithinFunction});
        }
    }

    void push(TypeId ty, Polarity polarity, bool isWithinFunction)
    {
        ty = follow(ty);
        if (!seenWithPolarity(ty, polarity) && !cachedTypes->contains(ty))
        {
            observe(ty, polarity);
            work.push_back({ty, polarity, isWithinFunction});
        }
    }

    void stepType(TypeId ty, Polarity polarity, bool isWithinFunction)
    {
        LUAU_ASSERT(!is<BoundType>(ty));

        if (auto ft = get<FreeType>(ty))
        {
            if (subsumes(scope, ft->scope))
            {
                GeneralizationParams<TypeId>& params = types[ty];
                params.useCount++;
                if (!isWithinFunction)
                    params.foundOutsideFunctions = true;

                params.polarity |= polarity;
            }

            push(ft->lowerBound, polarity, isWithinFunction);
            push(ft->upperBound, polarity, isWithinFunction);
        }
        else if (auto funTy = get<FunctionType>(ty))
        {
            push(funTy->argTypes, invert(polarity), true);
            push(funTy->retTypes, polarity, true);
        }
        else if (auto tt = get<TableType>(ty))
        {
            if ((tt->state == TableState::Free || tt->state == TableState::Unsealed) && subsumes(scope, tt->scope))
                unsealedTables.insert(ty);

            if (tt->indexer)
            {
                Polarity p = tt->indexer->isReadOnly ? polarity : Polarity::Mixed;
                push(tt->indexer->indexResultType, p, isWithinFunction);
                push(tt->indexer->indexType, p, isWithinFunction);
            }

            for (const auto& [_, prop] : tt->props)
            {
                if (prop.isShared())
                    push(*prop.readTy, Polarity::Mixed, isWithinFunction);
                else
                {
                    if (prop.readTy)
                        push(*prop.readTy, polarity, isWithinFunction);
                    if (prop.writeTy)
                        push(*prop.writeTy, invert(polarity), isWithinFunction);
                }
            }
        }
        else if (auto lt = get<LazyType>(ty))
        {
            if (TypeId unwrapped = lt->unwrapped)
                push(unwrapped, polarity, isWithinFunction);
        }
        else if (auto mt = get<MetatableType>(ty))
        {
            push(mt->metatable, polarity, isWithinFunction);
            push(mt->table, polarity, isWithinFunction);
        }
        else if (auto utv = get<UnionType>(ty))
        {
            for (auto option : utv)
                push(option, polarity, isWithinFunction);
        }
        else if (auto itv = get<IntersectionType>(ty))
        {
            for (auto part : itv)
                push(part, polarity, isWithinFunction);
        }
        else if (auto nt = get<NegationType>(ty))
            push(nt->ty, polarity, isWithinFunction);
        else if (auto tfit = get<TypeFunctionInstanceType>(ty))
        {
            for (auto typeArg : tfit->typeArguments)
                push(typeArg, polarity, isWithinFunction);

            for (auto packArg : tfit->packArguments)
                push(packArg, polarity, isWithinFunction);
        }
        else
        {
            LUAU_ASSERT(
                (is<PendingExpansionType,
                    BlockedType,
                    GenericType,
                    ErrorType,
                    PrimitiveType,
                    SingletonType,
                    AnyType,
                    NoRefineType,
                    UnknownType,
                    NeverType,
                    ExternType>(ty))
            );
        }
    }

    void stepTypePack(TypePackId tp, Polarity polarity, bool isWithinFunction)
    {
        LUAU_ASSERT(!is<BoundTypePack>(tp));

        if (auto ftp = get<FreeTypePack>(tp))
        {
            if (subsumes(scope, ftp->scope))
            {
                GeneralizationParams<TypePackId>& params = typePacks[tp];
                params.useCount++;

                if (!isWithinFunction)
                    params.foundOutsideFunctions = true;

                params.polarity |= polarity;
            }
        }
        else if (auto pack = get<TypePack>(tp))
        {
            for (auto hd : pack->head)
                push(hd, polarity, isWithinFunction);

            if (pack->tail)
                push(*pack->tail, polarity, isWithinFunction);
        }
        else if (auto vtp = get<VariadicTypePack>(tp))
        {
            push(vtp->ty, polarity, isWithinFunction);
        }
        else if (auto tfit = get<TypeFunctionInstanceTypePack>(tp))
        {
            for (auto typeArg : tfit->typeArguments)
                push(typeArg, polarity, isWithinFunction);

            for (auto packArg : tfit->packArguments)
                push(packArg, polarity, isWithinFunction);
        }
        else
        {
            LUAU_ASSERT((is<GenericTypePack, BlockedTypePack, ErrorTypePack>(tp)));
        }
    }

    void run(TypeId ty)
    {
        work.reserve(32);
        work.clear();
        push(ty, Polarity::Positive, false);

        while (!work.empty())
        {
            WorkItem item = work.back();
            work.pop_back();
            visit(
                overloaded{
                    [&](TypeId ty)
                    {
                        stepType(ty, item.polarity, item.isWithinFunction);
                    },
                    [&](TypePackId tp)
                    {
                        stepTypePack(tp, item.polarity, item.isWithinFunction);
                    }
                },
                item.value
            );
        }
    }
};

} // namespace


GeneralizationResult<TypeId> generalizeType(
    NotNull<TypeArena> arena,
    NotNull<BuiltinTypes> builtinTypes,
    NotNull<Scope> scope,
    TypeId freeTy,
    const GeneralizationParams<TypeId>& params
)
{
    freeTy = follow(freeTy);

    // Collapse any direct-bound cycle this free type participates in before we
    // commit to a generalization decision.  This handles the per-call
    // invocations from ConstraintSolver -- which bypass the batch pre-pass in
    // generalize() -- and is a no-op when the cycle has already been collapsed
    // by that pre-pass.  When this fires, freeTy may be re-bound to the
    // representative of the cycle, so we re-follow it.
    if (FFlag::LuauRemovePrimitiveTypeConstraintAndSubtypingUnifier)
    {
        // Run this and unconditionally re-follow.
        collapseDirectBoundCycleAt(arena, builtinTypes, freeTy);
        freeTy = follow(freeTy);
    }
    else if (collapseDirectBoundCycleAt(arena, builtinTypes, freeTy))
        freeTy = follow(freeTy);

    if (!get<FreeType>(freeTy))
        return {freeTy, /*wasReplacedByGeneric*/ false};

    FreeType* ft = getMutable<FreeType>(freeTy);
    LUAU_ASSERT(ft);

    LUAU_ASSERT(isKnown(params.polarity));

    const bool hasLowerBound = !get<NeverType>(follow(ft->lowerBound));
    const bool hasUpperBound = !get<UnknownType>(follow(ft->upperBound));

    const bool isWithinFunction = !params.foundOutsideFunctions;

    if (!hasLowerBound && !hasUpperBound)
    {
        if (!isWithinFunction)
            emplaceType<BoundType>(asMutable(freeTy), builtinTypes->unknownType);
        else
        {
            emplaceType<GenericType>(asMutable(freeTy), scope, params.polarity);
            return {freeTy, /*wasReplacedByGeneric*/ true};
        }
    }
    // It is possible that this free type has other free types in its upper
    // or lower bounds.  If this is the case, we must replace those
    // references with never (for the lower bound) or unknown (for the upper
    // bound).
    //
    // If we do not do this, we get tautological bounds like a <: a <: unknown.
    else if (isPositive(params.polarity) && !hasUpperBound)
    {
        TypeId lb = follow(ft->lowerBound);
        removeType(arena, builtinTypes, lb, freeTy);

        if (follow(lb) != freeTy)
            emplaceType<BoundType>(asMutable(freeTy), lb);
        else if (!isWithinFunction)
            emplaceType<BoundType>(asMutable(freeTy), builtinTypes->unknownType);
        else
        {
            // if the lower bound is the type in question (eg 'a <: 'a), we don't actually have a lower bound.
            emplaceType<GenericType>(asMutable(freeTy), scope, params.polarity);
            return {freeTy, /*wasReplacedByGeneric*/ true};
        }
    }
    else
    {
        TypeId ub = follow(ft->upperBound);
        // The pre-pass collapseDirectBoundCycleAt has already collapsed any
        // 2-cycle here, so there is no neighbor bound to forward -- just
        // strip the free type from the upper bound.
        removeType(arena, builtinTypes, ub, freeTy);

        if (follow(ub) != freeTy)
            emplaceType<BoundType>(asMutable(freeTy), ub);
        else if (!isWithinFunction || params.useCount == 1)
        {
            // If we have some free type:
            //
            //  A <: 'b <: C
            //
            // We can approximately generalize this to the intersection of its
            // bounds, taking care to avoid constructing a degenerate
            // union or intersection by clipping the free type from the upper
            // and lower bounds, then also cleaning the resulting intersection.
            removeType(arena, builtinTypes, ft->lowerBound, freeTy);
            TypeId cleanedTy = arena->addType(IntersectionType{{ft->lowerBound, ub}});
            removeType(arena, builtinTypes, cleanedTy, freeTy);
            emplaceType<BoundType>(asMutable(freeTy), cleanedTy);
        }
        else
        {
            // if the upper bound is the type in question, we don't actually have an upper bound.
            emplaceType<GenericType>(asMutable(freeTy), scope, params.polarity);
            return {freeTy, /*wasReplacedByGeneric*/ true};
        }
    }

    return {freeTy, /*wasReplacedByGeneric*/ false};
}

GeneralizationResult<TypePackId> generalizeTypePack(
    NotNull<TypeArena> arena,
    NotNull<BuiltinTypes> builtinTypes,
    NotNull<Scope> scope,
    TypePackId tp,
    const GeneralizationParams<TypePackId>& params
)
{
    tp = follow(tp);

    if (tp->owningArena != arena)
        return {tp, /*wasReplacedByGeneric*/ false};

    const FreeTypePack* ftp = get<FreeTypePack>(tp);
    if (!ftp)
        return {tp, /*wasReplacedByGeneric*/ false};

    if (!subsumes(scope, ftp->scope))
        return {tp, /*wasReplacedByGeneric*/ false};

    if (1 == params.useCount)
        emplaceTypePack<BoundTypePack>(asMutable(tp), builtinTypes->unknownTypePack);
    else
    {
        emplaceTypePack<GenericTypePack>(asMutable(tp), scope, params.polarity);
        return {tp, /*wasReplacedByGeneric*/ true};
    }

    return {tp, /*wasReplacedByGeneric*/ false};
}

void sealTable(NotNull<Scope> scope, TypeId ty)
{
    TableType* tableTy = getMutable<TableType>(follow(ty));
    if (!tableTy)
        return;

    if (!subsumes(scope, tableTy->scope))
        return;

    if (tableTy->state == TableState::Unsealed || tableTy->state == TableState::Free)
        tableTy->state = TableState::Sealed;
}

std::optional<TypeId> generalize(
    NotNull<TypeArena> arena,
    NotNull<BuiltinTypes> builtinTypes,
    NotNull<Scope> scope,
    NotNull<DenseHashSet<TypeId>> cachedTypes,
    TypeId ty,
    std::optional<TypeId> generalizationTarget
)
{
    ty = follow(ty);

    if (ty->owningArena != arena || ty->persistent)
        return ty;

    if (FFlag::LuauIterativeTypeSearcher)
    {
        CollectFreeTypePolarities cftp{scope, cachedTypes};
        cftp.run(ty);

        FunctionType* functionTy = getMutable<FunctionType>(ty);
        auto pushGeneric = [&](TypeId t)
        {
            if (functionTy)
                functionTy->generics.push_back(t);
        };

        auto pushGenericPack = [&](TypePackId tp)
        {
            if (functionTy)
                functionTy->genericPacks.push_back(tp);
        };

        if (!generalizationTarget)
            collapseFreeTypeCycles(arena, builtinTypes, cftp.types);

        auto generalizeJustOne = [&](TypeId freeTy, const auto& params)
        {
            if (!get<FreeType>(follow(freeTy)))
                return GeneralizationResult<TypeId>{};

            GeneralizationResult<TypeId> res = generalizeType(arena, builtinTypes, scope, freeTy, params);

            if (res.resourceLimitsExceeded)
                return res;

            if (res && res.wasReplacedByGeneric)
                pushGeneric(*res.result);

            return res;
        };

        if (generalizationTarget)
        {
            auto it = cftp.types.find(*generalizationTarget);
            if (it != cftp.types.end())
            {
                const auto [freeTy, params] = *it;
                auto res = generalizeJustOne(freeTy, params);
                if (res.resourceLimitsExceeded)
                    return std::nullopt;
            }
        }
        else
        {
            for (const auto& [freeTy, params] : cftp.types)
            {
                auto res = generalizeJustOne(freeTy, params);
                if (res.resourceLimitsExceeded)
                    return std::nullopt;
            }
        }

        for (TypeId unsealedTableTy : cftp.unsealedTables)
        {
            if (generalizationTarget && unsealedTableTy != *generalizationTarget)
                continue;

            sealTable(scope, unsealedTableTy);
        }

        for (const auto& [freePackId, params] : cftp.typePacks)
        {
            TypePackId freePack = follow(freePackId);
            if (!generalizationTarget)
            {
                GeneralizationResult<TypePackId> generalizedTp = generalizeTypePack(arena, builtinTypes, scope, freePack, params);

                if (generalizedTp.resourceLimitsExceeded)
                    return std::nullopt;

                if (generalizedTp && generalizedTp.wasReplacedByGeneric)
                    pushGenericPack(freePack);
            }
        }
    }
    else
    {

        FreeTypeSearcher_DEPRECATED fts{scope, cachedTypes};
        fts.traverse(ty);

        FunctionType* functionTy = getMutable<FunctionType>(ty);
        auto pushGeneric = [&](TypeId t)
        {
            if (functionTy)
                functionTy->generics.push_back(t);
        };

        auto pushGenericPack = [&](TypePackId tp)
        {
            if (functionTy)
                functionTy->genericPacks.push_back(tp);
        };

        if (!generalizationTarget)
            collapseFreeTypeCycles(arena, builtinTypes, fts.types);

        auto generalizeJustOne = [&](TypeId freeTy, const auto& params)
        {
            if (!get<FreeType>(follow(freeTy)))
                return GeneralizationResult<TypeId>{};

            GeneralizationResult<TypeId> res = generalizeType(arena, builtinTypes, scope, freeTy, params);

            if (res.resourceLimitsExceeded)
                return res;

            if (res && res.wasReplacedByGeneric)
                pushGeneric(*res.result);

            return res;
        };

        if (generalizationTarget)
        {
            auto it = fts.types.find(*generalizationTarget);
            if (it != fts.types.end())
            {
                const auto [freeTy, params] = *it;
                auto res = generalizeJustOne(freeTy, params);
                if (res.resourceLimitsExceeded)
                    return std::nullopt;
            }
        }
        else
        {
            for (const auto& [freeTy, params] : fts.types)
            {
                auto res = generalizeJustOne(freeTy, params);
                if (res.resourceLimitsExceeded)
                    return std::nullopt;
            }
        }

        for (TypeId unsealedTableTy : fts.unsealedTables)
        {
            if (generalizationTarget && unsealedTableTy != *generalizationTarget)
                continue;

            sealTable(scope, unsealedTableTy);
        }

        for (const auto& [freePackId, params] : fts.typePacks)
        {
            TypePackId freePack = follow(freePackId);
            if (!generalizationTarget)
            {
                GeneralizationResult<TypePackId> generalizedTp = generalizeTypePack(arena, builtinTypes, scope, freePack, params);

                if (generalizedTp.resourceLimitsExceeded)
                    return std::nullopt;

                if (generalizedTp && generalizedTp.wasReplacedByGeneric)
                    pushGenericPack(freePack);
            }
        }
    }

    TypeCacher cacher{cachedTypes};
    cacher.traverse(ty);

    return ty;
}

struct GenericCounter : TypeVisitor
{
    struct CounterState
    {
        size_t count = 0;
        Polarity polarity = Polarity::None;
    };

    // This traversal does need to walk into types multiple times because we
    // care about generics that are only referred to once. If a type is present
    // more than once, however, we don't care exactly how many times, so we also
    // track counts in our "seen set."
    DenseHashMap<TypeId, size_t> seenCounts;

    NotNull<DenseHashSet<TypeId>> cachedTypes;
    DenseHashMap<TypeId, CounterState> generics;
    DenseHashMap<TypePackId, CounterState> genericPacks;

    Polarity polarity = Polarity::Positive;

    int steps = 0;
    bool hitLimits = false;

    explicit GenericCounter(NotNull<DenseHashSet<TypeId>> cachedTypes)
        : TypeVisitor("GenericCounter", /* skipBoundTypes */ true)
        , cachedTypes(cachedTypes)
    {
    }

    void checkLimits()
    {
        steps++;
        hitLimits |= steps > FInt::LuauGenericCounterMaxSteps;
    }

    bool visit(TypeId ty) override
    {
        checkLimits();
        return !hitLimits;
    }


    bool visit(TypeId ty, const FunctionType& ft) override
    {
        checkLimits();

        if (ty->persistent)
            return false;

        size_t& seenCount = seenCounts[ty];
        if (seenCount > 1)
            return false;

        ++seenCount;

        polarity = invert(polarity);
        traverse(ft.argTypes);
        polarity = invert(polarity);
        traverse(ft.retTypes);

        return false;
    }

    bool visit(TypeId ty, const TableType& tt) override
    {
        checkLimits();

        if (ty->persistent)
            return false;

        size_t& seenCount = seenCounts[ty];
        if (seenCount > 1)
            return false;
        ++seenCount;

        const Polarity previous = polarity;

        for (const auto& [_name, prop] : tt.props)
        {
            if (prop.isReadOnly())
            {
                traverse(*prop.readTy);
            }
            else if (prop.isWriteOnly())
            {
                Polarity p = polarity;
                polarity = Polarity::Negative;
                traverse(*prop.writeTy);
                polarity = p;
            }
            else if (prop.isShared())
            {
                Polarity p = polarity;
                polarity = Polarity::Mixed;
                traverse(*prop.readTy);
                polarity = p;
            }
            else
            {
                LUAU_ASSERT(prop.isReadWrite() && !prop.isShared());

                traverse(*prop.readTy);
                Polarity p = polarity;
                polarity = Polarity::Negative;
                traverse(*prop.writeTy);
                polarity = p;
            }
        }

        if (tt.indexer)
        {
            polarity = Polarity::Mixed;
            traverse(tt.indexer->indexType);
            traverse(tt.indexer->indexResultType);
            polarity = previous;
        }

        return false;
    }

    bool visit(TypeId ty, const ExternType&) override
    {
        return false;
    }

    bool visit(TypeId ty, const GenericType&) override
    {
        auto state = generics.find(ty);
        if (state)
        {
            ++state->count;
            state->polarity |= polarity;
        }

        return false;
    }

    bool visit(TypePackId tp, const GenericTypePack&) override
    {
        auto state = genericPacks.find(tp);
        if (state)
        {
            ++state->count;
            state->polarity |= polarity;
        }

        return false;
    }
};

void pruneUnnecessaryGenerics(
    NotNull<TypeArena> arena,
    NotNull<BuiltinTypes> builtinTypes,
    NotNull<Scope> scope,
    NotNull<DenseHashSet<TypeId>> cachedTypes,
    TypeId ty
)
{
    ty = follow(ty);

    if (ty->owningArena != arena || ty->persistent)
        return;

    FunctionType* functionTy = getMutable<FunctionType>(ty);

    if (!functionTy)
        return;

    // If a generic has no explicit name and is only referred to in one place in
    // the function's signature, it can be replaced with unknown.

    GenericCounter counter{cachedTypes};
    for (TypeId generic : functionTy->generics)
    {
        generic = follow(generic);
        auto g = get<GenericType>(generic);
        if (g && !g->explicitName)
            counter.generics[generic] = {};
    }

    // It is sometimes the case that a pack in the generic list will become a
    // pack that (transitively) has a generic tail.  If it does, we need to add
    // that generic tail to the generic pack list.
    for (size_t i = 0; i < functionTy->genericPacks.size(); ++i)
    {
        TypePackId genericPack = follow(functionTy->genericPacks[i]);

        TypePackId tail = getTail(genericPack);

        if (tail != genericPack)
            functionTy->genericPacks.push_back(tail);

        if (auto g = get<GenericTypePack>(tail); g && !g->explicitName)
            counter.genericPacks[genericPack] = {};
    }

    counter.traverse(ty);

    if (!counter.hitLimits)
    {
        for (const auto& [generic, state] : counter.generics)
        {
            if (state.count == 1 && state.polarity != Polarity::Mixed)
            {
                if (arena.get() != generic->owningArena)
                    continue;
                emplaceType<BoundType>(asMutable(generic), builtinTypes->unknownType);
            }
        }
    }

    // Remove duplicates and types that aren't actually generics.
    DenseHashSet<TypeId> seen;
    auto it = std::remove_if(
        functionTy->generics.begin(),
        functionTy->generics.end(),
        [&](TypeId ty)
        {
            ty = follow(ty);
            if (seen.contains(ty))
                return true;
            seen.insert(ty);

            if (!counter.hitLimits)
            {
                auto state = counter.generics.find(ty);
                if (state && state->count == 0)
                    return true;
            }

            return !get<GenericType>(ty);
        }
    );

    functionTy->generics.erase(it, functionTy->generics.end());


    if (!counter.hitLimits)
    {
        for (const auto& [genericPack, state] : counter.genericPacks)
        {
            if (state.count == 1)
                emplaceTypePack<BoundTypePack>(asMutable(genericPack), builtinTypes->unknownTypePack);
        }
    }


    DenseHashSet<TypePackId> seen2;
    auto it2 = std::remove_if(
        functionTy->genericPacks.begin(),
        functionTy->genericPacks.end(),
        [&](TypePackId tp)
        {
            tp = follow(tp);
            if (seen2.contains(tp))
                return true;
            seen2.insert(tp);

            if (!counter.hitLimits)
            {
                auto state = counter.genericPacks.find(tp);
                if (state && state->count == 0)
                    return true;
            }

            return !get<GenericTypePack>(tp);
        }
    );

    functionTy->genericPacks.erase(it2, functionTy->genericPacks.end());
}

} // namespace Luau
