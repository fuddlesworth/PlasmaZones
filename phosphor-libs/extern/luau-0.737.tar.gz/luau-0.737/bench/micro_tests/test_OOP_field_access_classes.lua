-- --bench-args: --fflags=DebugLuauUserDefinedClasses,DebugLuauUserDefinedClassesRuntime,LuauCallFeedback,LuauEmitCallFeedback
local function prequire(name) local success, result = pcall(require, name); return success and result end
local bench = script and require(script.Parent.bench_support) or prequire("bench_support") or require("../bench_support")

class Number
    public value
    function Get(self)
        return self.value
    end
end

function test()

    local n = Number.new({ value = 42 })

    local ts0 = os.clock()
    for i=1,10_000_000 do
        local _ = n.value
    end
    local ts1 = os.clock()

    return ts1-ts0
end

bench.runCode(test, "OOP: field access class")
