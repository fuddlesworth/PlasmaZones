// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
#include "Luau/JitInliner.h"

#include "Luau/Bytecode.h"
#include "Luau/BytecodeCallInliner.h"
#include "Luau/BytecodeDump.h"
#include "Luau/BytecodeGraph.h"
#include "Luau/BytecodeUtils.h"
#include "Luau/Common.h"
#include "Luau/Sccp.h"

#include "BytecodeGraphParser.h"
#include "BytecodeGraphSerializer.h"
#include "RuntimeBytecodeBuilder.h"
#include "TValueVmConstImpl.h"

#include "lfunc.h"
#include "lgc.h"
#include "lmem.h"
#include "lobject.h"
#include "lstate.h"

#include <cstdio>
#include <optional>

LUAU_FASTINTVARIABLE(LuauJitInlineThreshold, 25)
LUAU_FASTINTVARIABLE(LuauJitInlineThresholdMaxBoost, 300)
LUAU_FASTINTVARIABLE(LuauJitInlineSmallFunSize, 128)
LUAU_FASTINTVARIABLE(LuauJitInlineTooLongFunSize, 0xFFFF);

LUAU_FASTFLAGVARIABLE(LuauBytecodeFold)

using namespace Luau::Bytecode;

namespace Luau
{
namespace JitInliner
{

using RuntimeBcFunction = BcFunction<TValue*>;

std::optional<std::pair<RuntimeBcFunction, BcOp>> buildGraphFromProto(Proto* p, std::optional<uint32_t> callPc = {})
{
    RuntimeBcFunction fn;

    fn.maxstacksize = p->maxstacksize;
    fn.numparams = p->numparams;
    fn.nups = p->nups;
    fn.is_vararg = static_cast<bool>(p->is_vararg);
    fn.flags = p->flags;
    fn.linedefined = p->linedefined;

    uint8_t* typeinfo = p->typeinfo;
    fn.typeInfo = std::string_view(reinterpret_cast<char*>(typeinfo), p->sizetypeinfo);

    fn.constants.resize(p->sizek);
    for (int i = 0; i < p->sizek; i++)
        fn.constants[i] = &p->k[i];

    fn.protos.resize(p->sizep);
    for (int i = 0; i < p->sizep; i++)
        fn.protos[i] = i;

    std::vector<uint32_t> lines(p->sizecode, 0);
    if (p->lineinfo != nullptr && p->abslineinfo != nullptr)
        for (int i = 0; i < p->sizecode; i++)
            lines[i] = p->abslineinfo[i >> p->linegaplog2] + p->lineinfo[i];

    std::vector<uint32_t> insnsPC;
    BytecodeGraphParser<TValue*> graphParser(fn);

    Instruction* code = p->code;
    if (!graphParser.rebuildGraph(code, p->sizecode, lines, insnsPC))
        return {};

    BcOp callOp;
    if (callPc)
    {
        LUAU_ASSERT(*callPc < insnsPC.size());
        callOp = BcOp{BcOpKind::Inst, insnsPC[*callPc]};
        LUAU_ASSERT(fn.inst(callOp)->op == LOP_CALLFB);
    }

    return {{fn, callOp}};
}

constexpr uint32_t kUnassignedPC = ~0;

std::optional<CodeData> emitCode(lua_State* L, RuntimeBcFunction& graph, std::vector<Proto*>& protos)
{
    RuntimeBytecodeBuilder bcb(L, graph.constants, protos);
    bcb.beginFunction(graph.numparams, graph.is_vararg);

    BytecodeGraphSerializer<TValue*> serializer(bcb, graph);
    std::vector<uint32_t> insnsPC = serializer.emitBytecode();

    if (insnsPC.size() == 0)
        return {};

    bcb.foldJumps();

    bool hasLongJumpError = false;
    std::vector<uint32_t> remap = bcb.expandJumps(hasLongJumpError);

    if (hasLongJumpError)
        return {};

    if (remap.size() > 0)
    {
        LUAU_ASSERT(insnsPC.size() <= remap.size());
        for (size_t i = 0; i < insnsPC.size(); i++)
            insnsPC[i] = remap[insnsPC[i]];
    }

    auto res = bcb.finishAndDumpCode(graph.maxstacksize, graph.nups);

    for (uint32_t i = 0; i < graph.instructions.size(); i++)
    {
        BcInst& insn = graph.instructions[i];
        if (insn.op == LOP_CALLFB && (graph.blockOp(insn.block).flags & BcBlockFlag::Dead) == 0)
        {
            BcCallFB<TValue*> callFB = graph.template as<BcCallFB<TValue*>>(BcOp{BcOpKind::Inst, i});
            if (callFB.FbSlot() >= 0)
            {
                uint32_t fbSlot = static_cast<uint32_t>(callFB.FbSlot());
                if (fbSlot >= res.fbSlotPCs.size())
                    res.fbSlotPCs.resize(fbSlot + 1, kUnassignedPC);

                res.fbSlotPCs[fbSlot] = insnsPC[i];
            }
        }
    }

    return {res};
}

Proto* createInlinedProto(lua_State* L, Proto* caller, Proto* target, RuntimeBcFunction& graph, CodeData& codeData)
{
    Proto* p = luaF_newproto(L);

    p->debugname = caller->debugname;
    p->maxstacksize = graph.maxstacksize;
    p->numparams = graph.numparams;
    p->nups = graph.nups;
    p->is_vararg = graph.is_vararg;
    p->flags = graph.flags;
    p->gclist = nullptr;
    p->funid = caller->funid;
    p->userdata = caller->userdata;
    p->source = caller->source;
    p->linedefined = caller->linedefined;

    p->k = luaM_newarray(L, graph.constants.size(), TValue, L->activememcat);
    p->sizek = int(graph.constants.size());
    for (int i = 0; i < p->sizek; i++)
        p->k[i] = *graph.constants[i];

    p->p = luaM_newarray(L, graph.protos.size(), Proto*, L->activememcat);
    p->sizep = int(graph.protos.size());
    LUAU_ASSERT(p->sizep == (caller->sizep + target->sizep));
    memcpy(p->p, caller->p, caller->sizep * sizeof(Proto*));
    memcpy(p->p + caller->sizep, target->p, target->sizep * sizeof(Proto*));

    p->code = luaM_newarray(L, codeData.code.size(), Instruction, L->activememcat);
    p->sizecode = int(codeData.code.size());
    memcpy(p->code, codeData.code.data(), p->sizecode * sizeof(Instruction));
    // Lineinfo data is preallocated by emitCode
    p->linegaplog2 = codeData.linegaplog2;
    p->abslineinfo = codeData.abslineinfo;
    p->lineinfo = codeData.lineinfo;
    p->sizelineinfo = codeData.sizelineinfo;
    p->codeentry = p->code;
    p->bytecodeid = caller->bytecodeid;
    p->cost = caller->cost;

    uint32_t feedbackvecsize = caller->feedbackvecsize + target->feedbackvecsize;
    p->feedbackvec = luaM_newarray(L, feedbackvecsize, FeedbackVectorSlot, L->activememcat);
    p->feedbackvecsize = feedbackvecsize;
    memcpy(p->feedbackvec, caller->feedbackvec, caller->feedbackvecsize * sizeof(FeedbackVectorSlot));
    memcpy(p->feedbackvec + caller->feedbackvecsize, target->feedbackvec, target->feedbackvecsize * sizeof(FeedbackVectorSlot));

    for (uint32_t i = 0; i < std::min<uint32_t>(p->feedbackvecsize, uint32_t(codeData.fbSlotPCs.size())); i++)
        if (codeData.fbSlotPCs[i] != kUnassignedPC)
        {
            LUAU_ASSERT(p->feedbackvec[i].kind == FeedbackVectorSlotKind::CALL_TARGET);
            p->feedbackvec[i].call_target.pc = codeData.fbSlotPCs[i];
        }

    p->deoptimized = caller;
    caller->optimized = p;
    luaC_objbarrier(L, caller, p);

    return p;
}

void sealAllSlots(Instruction* code, uint32_t codesize)
{
    Instruction* codeend = code + codesize;
    for (Instruction* pc = code; pc < codeend;)
    {
        if (LUAU_INSN_OP(*pc) == LOP_CALLFB)
            *(pc + 1) = 0xFFFFFFFF;
        pc += Luau::getOpLength(static_cast<LuauOpcode>(LUAU_INSN_OP(*pc)));
    }
}

// Extracted from Compiler/src/CostModel.cpp
int computeCost(uint64_t model, std::vector<bool> varsConst)
{
    int cost = int(model & 0x7f);

    // don't apply discounts to what is likely a saturated sum
    if (cost == 0x7f)
        return cost;

    for (size_t i = 0; i < varsConst.size() && i < 7; ++i)
        cost -= int((model >> (i * 8 + 8)) & 0x7f) * static_cast<int>(varsConst[i]);

    return cost;
}

bool isConstOp(RuntimeBcFunction& graph, BcOp op)
{
    if (op.kind == BcOpKind::Inst)
    {
        BcInst& inst = graph.instOp(op);
        switch (inst.op)
        {
        case LOP_LOADB:
        case LOP_LOADNIL:
        case LOP_LOADN:
        case LOP_LOADK:
        case LOP_LOADKX:
            return true;
        case LOP_MOVE:
            return isConstOp(graph, inst.ops[0]);
        default:
            return false;
        }
    }
    return false;
}

bool hasFoldableConstants(const RuntimeBcFunction& func)
{
    for (const BcInst& inst : func.instructions)
    {
        switch (inst.op)
        {
        case LOP_LOADK:
        case LOP_LOADKX:
        case LOP_LOADN:
        case LOP_LOADB:
        case LOP_LOADNIL:
            return true;
        default:
            break;
        }
    }
    return false;
}

bool isEnvDependentOrUsesSelect(Proto* proto, bool crossEnv)
{
    Instruction* codeend = proto->code + proto->sizecode;
    for (Instruction* pc = proto->code; pc < codeend;)
    {
        switch (LUAU_INSN_OP(*pc))
        {
            case LOP_GETIMPORT:
            {
                uint16_t importKIndex = LUAU_INSN_D(*pc);
                LUAU_ASSERT(importKIndex < static_cast<uint16_t>(proto->sizek));
                // if import is unresolved we cannot inline target, because globals can differ in the caller's env.
                if (crossEnv && ttisnil(proto->k + importKIndex))
                    return true;
                break;
            }
            case LOP_GETGLOBAL:
            case LOP_SETGLOBAL:
            case LOP_NEWCLOSURE:
            case LOP_DUPCLOSURE:
            {
                if (crossEnv)
                    return true;
                break;
            }
            case LOP_FASTCALL1:
            case LOP_FASTCALL2:
            case LOP_FASTCALL2K:
            case LOP_FASTCALL3:
            case LOP_FASTCALL:
            {
                if (LUAU_INSN_A(*pc) == LBF_SELECT_VARARG)
                    return true;
                break;
            }
            default:
                break;
        }
        pc += Luau::getOpLength(static_cast<LuauOpcode>(LUAU_INSN_OP(*pc)));
    }
    return false;
}

Proto* onInlineFunction(lua_State* L, Closure* caller, Closure* target, uint32_t pc)
{
    LUAU_ASSERT(!caller->isC && !target->isC);

    Proto* callerProto = caller->l.p;
    Proto* targetProto = target->l.p;

    // Checking if a caller was optimized already.
    if (callerProto->optimized != nullptr)
        return nullptr;

    if ((targetProto->flags & LPF_INLINABLE) == 0)
        return nullptr;

    LUAU_ASSERT(target->nupvalues == 0);

    // recursive inlining is not supported yet.
    if (targetProto->funid == callerProto->funid)
        return nullptr;

    if (caller->env->safeenv == 0 || target->env->safeenv == 0)
        return nullptr;
    
    if (isEnvDependentOrUsesSelect(targetProto, caller->env != target->env))
        return nullptr;

    // pick the latest optimized version for inlining
    while (targetProto->optimized != nullptr)
        targetProto = targetProto->optimized;

    if (callerProto->sizecode > FInt::LuauJitInlineTooLongFunSize || targetProto->sizecode > FInt::LuauJitInlineTooLongFunSize)
        return nullptr;

    auto callerGraph = buildGraphFromProto(callerProto, pc);
    if (!callerGraph)
        return nullptr;

    if (targetProto->cost != 0 && targetProto->sizecode > FInt::LuauJitInlineSmallFunSize)
    {
        // Can we calculate constness of arguments before building a caller's graph?
        std::vector<bool> params;
        int baselineCost = computeCost(targetProto->cost, params) + 3;
        BcCallFB<TValue*> call = callerGraph->first.template as<BcCallFB<TValue*>>(callerGraph->second);
        for (BcOp arg : call.params())
        {
            if (params.size() == 7)
                break;
            params.push_back(isConstOp(callerGraph->first, arg));
        }
        int inlinedCost = computeCost(targetProto->cost, params);
        int inlineProfit = (inlinedCost == 0) ? FInt::LuauJitInlineThresholdMaxBoost
                                              : std::min<int>(FInt::LuauJitInlineThresholdMaxBoost, 100 * baselineCost / inlinedCost);
        int threshold = FInt::LuauJitInlineThreshold * inlineProfit / 100;
        if (inlinedCost > threshold)
        {
            return nullptr;
        }
    }

    auto targetGraph = buildGraphFromProto(targetProto);

    if (!targetGraph)
        return nullptr;

    if (!inlineCall(callerGraph->first, targetGraph->first, callerGraph->second, targetProto->funid, callerProto->feedbackvecsize))
        return nullptr;

    // impl must outlive emitCode and createInlinedProto
    std::optional<TValueVmConstImpl> impl;
    if (FFlag::LuauBytecodeFold && hasFoldableConstants(callerGraph->first))
    {
        impl.emplace(L, callerGraph->first);
        foldConstants(callerGraph->first, *impl);
    }

    std::vector<Proto*> protos;
    protos.resize(callerProto->sizep + targetProto->sizep);
    memcpy(protos.data(), callerProto->p, callerProto->sizep * sizeof(Proto*));
    memcpy(protos.data() + callerProto->sizep, targetProto->p, targetProto->sizep * sizeof(Proto*));

    if (std::optional<CodeData> codeData = emitCode(L, callerGraph->first, protos))
    {
        createInlinedProto(L, callerProto, targetProto, callerGraph->first, *codeData);
    }

    // To prevent triggering of optimizations in already optimized proto sealing all feedback slots.
    // All hit info was copied to the optimized version and new optimizations will happen there.
    sealAllSlots(callerProto->code, callerProto->sizecode);

    return nullptr;
}

void setup(lua_State* L)
{
    L->global->ecb.inlinefunction = onInlineFunction;
}

void disable(lua_State* L)
{
    L->global->ecb.inlinefunction = nullptr;
}

} // namespace JitInliner
} // namespace Luau
